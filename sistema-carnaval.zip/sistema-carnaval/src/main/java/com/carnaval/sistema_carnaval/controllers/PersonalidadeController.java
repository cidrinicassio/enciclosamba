package com.carnaval.sistema_carnaval.controllers;

import com.carnaval.sistema_carnaval.models.Personalidade;
import com.carnaval.sistema_carnaval.services.PersonalidadeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/personalidades")
public class PersonalidadeController {

    private final PersonalidadeService service;

    public PersonalidadeController(PersonalidadeService service) {
        this.service = service;
    }

    @GetMapping
    public List<Personalidade> listarTodas() {
        return service.listarTodas();
    }

    @GetMapping("/filtro")
    public List<Personalidade> buscarComFiltro(
            @RequestParam(required = false) String nomeCompleto,
            @RequestParam(required = false) String nomeArtistico) {
        return service.buscarComFiltro(nomeCompleto, nomeArtistico);
    }

    @GetMapping("/{id:[0-9]+}")
    public ResponseEntity<Personalidade> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> cadastrar(@RequestBody Personalidade novaPersonalidade) {
        try {
            return ResponseEntity.ok(service.salvar(novaPersonalidade));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id:[0-9]+}")
    public ResponseEntity<Personalidade> atualizar(@PathVariable Long id, @RequestBody Personalidade personalidadeAtualizada) {
        return service.atualizar(id, personalidadeAtualizada)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id:[0-9]+}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (service.deletar(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
