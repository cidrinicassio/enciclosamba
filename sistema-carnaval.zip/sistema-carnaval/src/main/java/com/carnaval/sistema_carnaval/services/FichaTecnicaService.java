package com.carnaval.sistema_carnaval.services;

import com.carnaval.sistema_carnaval.models.Cargo;
import com.carnaval.sistema_carnaval.models.FichaTecnica;
import com.carnaval.sistema_carnaval.repositories.DesfileRepository;
import com.carnaval.sistema_carnaval.repositories.FichaTecnicaRepository;
import com.carnaval.sistema_carnaval.repositories.PersonalidadeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FichaTecnicaService {

    private static final Logger log = LoggerFactory.getLogger(FichaTecnicaService.class);

    private final FichaTecnicaRepository repository;
    private final DesfileRepository desfileRepository;
    private final PersonalidadeRepository personalidadeRepository;

    public FichaTecnicaService(FichaTecnicaRepository repository,
                               DesfileRepository desfileRepository,
                               PersonalidadeRepository personalidadeRepository) {
        this.repository = repository;
        this.desfileRepository = desfileRepository;
        this.personalidadeRepository = personalidadeRepository;
    }

    public List<FichaTecnica> listarTodas() {
        List<FichaTecnica> resultado = repository.findAll();
        log.debug("Listando todas as fichas técnicas — {} encontradas", resultado.size());
        return resultado;
    }

    public List<FichaTecnica> listarPorDesfile(Long desfileId) {
        log.debug("Listando fichas técnicas do desfile id={}", desfileId);
        List<FichaTecnica> resultado = repository.findByDesfileId(desfileId);
        log.debug("Fichas técnicas do desfile id={}: {} encontradas", desfileId, resultado.size());
        return resultado;
    }

    public List<FichaTecnica> buscarComFiltro(Long desfileId, String cargo) {
        Cargo cargoEnum = null;
        if (cargo != null && !cargo.trim().isEmpty()) {
            cargoEnum = Cargo.valueOf(cargo.trim().toUpperCase());
        }
        log.debug("Buscando fichas técnicas com filtro desfileId={}, cargo={}", desfileId, cargoEnum);
        List<FichaTecnica> resultado = repository.buscarComFiltro(desfileId, cargoEnum);
        log.debug("Busca de fichas técnicas retornou {} resultado(s)", resultado.size());
        return resultado;
    }

    public Optional<FichaTecnica> buscarPorId(Long id) {
        log.debug("Buscando ficha técnica id={}", id);
        Optional<FichaTecnica> ficha = repository.findById(id);
        if (ficha.isEmpty()) {
            log.warn("Ficha técnica id={} não encontrada", id);
        }
        return ficha;
    }

    public FichaTecnica salvar(FichaTecnica novaFicha) {
        if (novaFicha.getDesfile() == null || novaFicha.getDesfile().getId() == null
                || !desfileRepository.existsById(novaFicha.getDesfile().getId())) {
            log.warn("Tentativa de salvar ficha técnica com desfile inválido: id={}",
                    novaFicha.getDesfile() != null ? novaFicha.getDesfile().getId() : null);
            throw new IllegalArgumentException("Desfile inválido ou não encontrado!");
        }
        if (novaFicha.getPersonalidade() == null || novaFicha.getPersonalidade().getId() == null
                || !personalidadeRepository.existsById(novaFicha.getPersonalidade().getId())) {
            log.warn("Tentativa de salvar ficha técnica com personalidade inválida: id={}",
                    novaFicha.getPersonalidade() != null ? novaFicha.getPersonalidade().getId() : null);
            throw new IllegalArgumentException("Personalidade inválida ou não encontrada!");
        }
        FichaTecnica salva = repository.save(novaFicha);
        log.info("Ficha técnica salva: id={}, desfile={}, personalidade={}, cargo={}",
                salva.getId(),
                salva.getDesfile().getId(),
                salva.getPersonalidade().getId(),
                salva.getCargo());
        return salva;
    }

    public Optional<FichaTecnica> atualizar(Long id, FichaTecnica fichaAtualizada) {
        log.debug("Atualizando ficha técnica id={}", id);
        return repository.findById(id).map(fichaExistente -> {
            fichaAtualizada.setId(id);
            FichaTecnica salva = repository.save(fichaAtualizada);
            log.info("Ficha técnica id={} atualizada: cargo={}", id, salva.getCargo());
            return salva;
        }).or(() -> {
            log.warn("Ficha técnica id={} não encontrada para atualizar", id);
            return Optional.empty();
        });
    }

    public boolean deletar(Long id) {
        if (!repository.existsById(id)) {
            log.warn("Ficha técnica id={} não encontrada para deletar", id);
            return false;
        }
        repository.deleteById(id);
        log.info("Ficha técnica id={} deletada", id);
        return true;
    }
}
