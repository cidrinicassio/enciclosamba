package com.carnaval.sistema_carnaval.services;

import com.carnaval.sistema_carnaval.models.Personalidade;
import com.carnaval.sistema_carnaval.repositories.PersonalidadeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class PersonalidadeService {

    private static final Logger log = LoggerFactory.getLogger(PersonalidadeService.class);

    private final PersonalidadeRepository repository;

    public PersonalidadeService(PersonalidadeRepository repository) {
        this.repository = repository;
    }

    public List<Personalidade> listarTodas() {
        List<Personalidade> resultado = repository.findAll();
        log.debug("Listando todas as personalidades — {} encontradas", resultado.size());
        return resultado;
    }

    public List<Personalidade> buscarComFiltro(String nomeCompleto, String nomeArtistico) {
        String nc = (nomeCompleto != null && !nomeCompleto.trim().isEmpty()) ? nomeCompleto.trim() : null;
        String na = (nomeArtistico != null && !nomeArtistico.trim().isEmpty()) ? nomeArtistico.trim() : null;
        log.debug("Buscando personalidades com filtro nomeCompleto='{}', nomeArtistico='{}'", nc, na);
        List<Personalidade> resultado = repository.buscarPorNome(nc, na);
        log.debug("Busca de personalidades retornou {} resultado(s)", resultado.size());
        return resultado;
    }

    public Optional<Personalidade> buscarPorId(Long id) {
        log.debug("Buscando personalidade id={}", id);
        Optional<Personalidade> personalidade = repository.findById(id);
        if (personalidade.isEmpty()) {
            log.warn("Personalidade id={} não encontrada", id);
        }
        return personalidade;
    }

    public Personalidade salvar(Personalidade novaPersonalidade) {
        if (novaPersonalidade.getDataNascimento() != null && novaPersonalidade.getDataNascimento().isAfter(LocalDate.now())) {
            log.warn("Tentativa de salvar personalidade '{}' com dataNascimento no futuro: {}",
                    novaPersonalidade.getNomeArtistico(), novaPersonalidade.getDataNascimento());
            throw new IllegalArgumentException("A data de nascimento não pode ser no futuro!");
        }
        if (novaPersonalidade.getDataFalecimento() != null && novaPersonalidade.getDataNascimento() != null
                && novaPersonalidade.getDataFalecimento().isBefore(novaPersonalidade.getDataNascimento())) {
            log.warn("Tentativa de salvar personalidade '{}' com dataFalecimento antes do dataNascimento",
                    novaPersonalidade.getNomeArtistico());
            throw new IllegalArgumentException("A data de falecimento não pode ser anterior à data de nascimento!");
        }
        Personalidade salva = repository.save(novaPersonalidade);
        log.info("Personalidade salva: id={}, nomeArtistico='{}'", salva.getId(), salva.getNomeArtistico());
        return salva;
    }

    public Optional<Personalidade> atualizar(Long id, Personalidade personalidadeAtualizada) {
        log.debug("Atualizando personalidade id={}", id);
        return repository.findById(id).map(personalidadeExistente -> {
            personalidadeAtualizada.setId(id);
            Personalidade salva = repository.save(personalidadeAtualizada);
            log.info("Personalidade id={} atualizada: nomeArtistico='{}'", id, salva.getNomeArtistico());
            return salva;
        }).or(() -> {
            log.warn("Personalidade id={} não encontrada para atualizar", id);
            return Optional.empty();
        });
    }

    public boolean deletar(Long id) {
        if (!repository.existsById(id)) {
            log.warn("Personalidade id={} não encontrada para deletar", id);
            return false;
        }
        repository.deleteById(id);
        log.info("Personalidade id={} deletada", id);
        return true;
    }
}
