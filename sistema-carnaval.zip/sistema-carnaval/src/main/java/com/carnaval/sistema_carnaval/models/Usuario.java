package com.carnaval.sistema_carnaval.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "tb_usuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String senha; // Guardará o hash Bcrypt da senha

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserRole role; // ADMIN ou USER

    /* --- COLUNAS TÁTICAS DE SEGURANÇA E MFA --- */

    @Column(nullable = false)
    private Integer tentativasFalhas = 0; // Se chegar a 3, bloqueia

    @Column(nullable = false)
    private Boolean contaBloqueada = false;

    private String codigoMfaAtual; // O código de 6 dígitos enviado por e-mail

    private LocalDateTime expiracaoMfa; // O relógio de 3 minutos para expirar

    private String preAuthToken; // O UUID temporário do primeiro passo do login
}