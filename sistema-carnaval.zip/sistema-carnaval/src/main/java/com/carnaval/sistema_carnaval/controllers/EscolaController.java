package com.carnaval.sistema_carnaval.controllers;

import com.carnaval.sistema_carnaval.models.Escola;
import com.carnaval.sistema_carnaval.services.EscolaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/escolas")
public class EscolaController {

    private final EscolaService service; // Agora o Controller fala APENAS com o Service!

    public EscolaController(EscolaService service) {
        this.service = service;
    }

    @GetMapping
    public List<Escola> listarTodas() {
        return service.listarTodas();
    }

    @GetMapping("/filtro")
    public List<Escola> buscarComFiltro(@RequestParam(required = false) String nome) {
        return service.buscarComFiltro(nome);
    }

    @GetMapping("/{id:[0-9]+}")
    public ResponseEntity<Escola> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> cadastrar(@RequestBody Escola novaEscola) {
        try {
            Escola escolaSalva = service.salvar(novaEscola);
            return ResponseEntity.ok(escolaSalva);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage()); // HTTP 400 se a regra falhar
        }
    }

    @ModelAttribute
    @PutMapping("/{id:[0-9]+}")
    public ResponseEntity<Escola> atualizar(@PathVariable Long id, @RequestBody Escola escolaAtualizada) {
        return service.atualizar(id, escolaAtualizada)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id:[0-9]+}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (service.deletar(id)) {
            return ResponseEntity.noContent().build(); // HTTP 204
        }
        return ResponseEntity.notFound().build(); // HTTP 404
    }
}