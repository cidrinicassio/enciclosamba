package com.carnaval.sistema_carnaval.controllers;

import com.carnaval.sistema_carnaval.models.SambaEnredo;
import com.carnaval.sistema_carnaval.services.SambaEnredoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sambas-enredo")
public class SambaEnredoController {

    private final SambaEnredoService service;

    public SambaEnredoController(SambaEnredoService service) {
        this.service = service;
    }

    @GetMapping
    public List<SambaEnredo> listarTodos() {
        return service.listarTodos();
    }

    @GetMapping("/filtro")
    public List<SambaEnredo> buscarComFiltro(
            @RequestParam(required = false) String titulo,
            @RequestParam(required = false) Integer ano) {
        return service.buscarComFiltro(titulo, ano);
    }

    @GetMapping("/{id:[0-9]+}")
    public ResponseEntity<SambaEnredo> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> cadastrar(@RequestBody SambaEnredo novoSamba) {
        try {
            return ResponseEntity.ok(service.salvar(novoSamba));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id:[0-9]+}")
    public ResponseEntity<SambaEnredo> atualizar(@PathVariable Long id, @RequestBody SambaEnredo sambaAtualizado) {
        return service.atualizar(id, sambaAtualizado)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id:[0-9]+}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (service.deletar(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
