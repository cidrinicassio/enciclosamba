package com.carnaval.sistema_carnaval.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "tb_personalidades")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Personalidade {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String nomeCompleto; // Ex: "Luiz Antônio Feliciano Marcondes"

    @Column(nullable = false, length = 80)
    private String nomeArtistico; // Ex: "Neguinho da Beija-Flor" (Crucial no samba!)

    private LocalDate dataNascimento;

    private LocalDate dataFalecimento; // Null se a pessoa estiver viva

    @Column(columnDefinition = "TEXT")
    private String biografia;

    @JsonIgnoreProperties("personalidade")
    @OneToMany(mappedBy = "personalidade", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<VinculoPersonalidadeEscola> historicoPorEscola;
}
