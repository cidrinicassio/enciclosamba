package com.carnaval.sistema_carnaval.models;

public enum UserRole {
    ADMIN("admin"), // Pode fazer POST, PUT, DELETE
    USER("user");   // Só pode fazer GET

    private String role;

    UserRole(String role) {
        this.role = role;
    }

    public String getRole() {
        return role;
    }
}