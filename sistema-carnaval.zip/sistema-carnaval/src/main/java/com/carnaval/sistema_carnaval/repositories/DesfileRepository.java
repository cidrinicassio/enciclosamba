package com.carnaval.sistema_carnaval.repositories;

import com.carnaval.sistema_carnaval.models.Desfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DesfileRepository extends JpaRepository<Desfile, Long> {

    @Query(nativeQuery = true, value =
        "SELECT d.* FROM tb_desfiles d " +
        "INNER JOIN tb_escolas e ON d.escola_id = e.id " +
        "WHERE (:ano IS NULL OR d.ano = :ano) AND " +
        "(:nomeEscola IS NULL OR " +
        " translate(unaccent(lower(e.nome)), '-', ' ') " +
        " LIKE '%' || translate(unaccent(lower(:nomeEscola)), '-', ' ') || '%')")
    List<Desfile> buscarPorAnoENomeEscola(
        @Param("ano") Integer ano,
        @Param("nomeEscola") String nomeEscola
    );
}