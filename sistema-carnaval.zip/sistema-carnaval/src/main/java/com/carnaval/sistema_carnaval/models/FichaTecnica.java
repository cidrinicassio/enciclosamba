package com.carnaval.sistema_carnaval.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "tb_fichas_tecnicas")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FichaTecnica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "desfile_id", nullable = false)
    private Desfile desfile;

    @ManyToOne
    @JoinColumn(name = "personalidade_id", nullable = false)
    private Personalidade personalidade;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Cargo cargo; // Guarda qual era a função daquela pessoa NAQUELE desfile
}