package com.carnaval.sistema_carnaval.dtos;

public record MfaRequest(String preAuthToken, String codigo) {
}