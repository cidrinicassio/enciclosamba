package com.carnaval.sistema_carnaval;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaCarnavalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaCarnavalApplication.class, args);
	}

}
