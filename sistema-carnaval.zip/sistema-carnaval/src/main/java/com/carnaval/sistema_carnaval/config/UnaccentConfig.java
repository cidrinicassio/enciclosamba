package com.carnaval.sistema_carnaval.config;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Statement;

@Component
public class UnaccentConfig {

    private final DataSource dataSource;

    public UnaccentConfig(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    public void createUnaccentExtension() {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE EXTENSION IF NOT EXISTS unaccent");
        } catch (Exception e) {
            throw new RuntimeException("Falha ao habilitar extensão unaccent no PostgreSQL", e);
        }
    }
}
