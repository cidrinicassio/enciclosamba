package com.carnaval.sistema_carnaval.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Entity
@Table(name = "tb_vinculos_personalidade_escola")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VinculoPersonalidadeEscola {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnoreProperties("historicoPorEscola")
    @ManyToOne
    @JoinColumn(name = "personalidade_id", nullable = false)
    private Personalidade personalidade;

    @JsonIgnoreProperties("historicoPorPersonalidade")
    @ManyToOne
    @JoinColumn(name = "escola_id", nullable = false)
    private Escola escola;

    private LocalDate dataInicio;

    private LocalDate dataFim; // null = vínculo ainda ativo
}
