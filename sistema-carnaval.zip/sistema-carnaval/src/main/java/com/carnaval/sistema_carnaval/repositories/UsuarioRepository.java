package com.carnaval.sistema_carnaval.repositories;

import com.carnaval.sistema_carnaval.models.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Optional<Usuario> findByEmail(String email);

    Optional<Usuario> findByPreAuthToken(String preAuthToken);
}