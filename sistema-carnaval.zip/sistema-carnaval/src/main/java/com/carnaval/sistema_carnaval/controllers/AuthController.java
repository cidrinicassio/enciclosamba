package com.carnaval.sistema_carnaval.controllers;

import com.carnaval.sistema_carnaval.dtos.LoginRequest;
import com.carnaval.sistema_carnaval.dtos.MfaRequest;
import com.carnaval.sistema_carnaval.models.UserRole;
import com.carnaval.sistema_carnaval.models.Usuario;
import com.carnaval.sistema_carnaval.services.AuthService;
import com.carnaval.sistema_carnaval.services.UsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;
    private final UsuarioService usuarioService;

    public AuthController(AuthService authService, UsuarioService usuarioService) {
        this.authService = authService;
        this.usuarioService = usuarioService;
    }

    // Rota auxiliar APENAS para criarmos nosso primeiro usuário de testes!
    @PostMapping("/register")
    public ResponseEntity<Usuario> registrar(@RequestBody Usuario novoUsuario) {
        novoUsuario.setRole(UserRole.ADMIN); // Nasce como diretor
        novoUsuario.setContaBloqueada(false);
        novoUsuario.setTentativasFalhas(0);
        return ResponseEntity.status(HttpStatus.CREATED).body(usuarioService.salvar(novoUsuario));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            return ResponseEntity.accepted().body(authService.iniciarLogin(request)); // HTTP 202
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage()); // HTTP 403 Bloqueado
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage()); // HTTP 401 Senha errada
        }
    }

    @PostMapping("/mfa")
    public ResponseEntity<?> mfa(@RequestBody MfaRequest request) {
        try {
            return ResponseEntity.ok(authService.concluirLogin(request)); // HTTP 200 Token entregue!
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }
}