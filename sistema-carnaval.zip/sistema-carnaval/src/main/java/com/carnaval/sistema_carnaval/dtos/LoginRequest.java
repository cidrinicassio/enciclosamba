package com.carnaval.sistema_carnaval.dtos;

public record LoginRequest(String email, String senha) {
}