package com.carnaval.sistema_carnaval.controllers;

import com.carnaval.sistema_carnaval.dtos.VinculoRequest;
import com.carnaval.sistema_carnaval.models.Escola;
import com.carnaval.sistema_carnaval.models.Personalidade;
import com.carnaval.sistema_carnaval.models.VinculoPersonalidadeEscola;
import com.carnaval.sistema_carnaval.services.VinculoPersonalidadeEscolaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/vinculos")
public class VinculoPersonalidadeEscolaController {

    private final VinculoPersonalidadeEscolaService service;

    public VinculoPersonalidadeEscolaController(VinculoPersonalidadeEscolaService service) {
        this.service = service;
    }

    @GetMapping
    public List<VinculoPersonalidadeEscola> listarTodos() {
        return service.listarTodos();
    }

    @GetMapping("/personalidade/{personalidadeId}")
    public List<VinculoPersonalidadeEscola> listarPorPersonalidade(@PathVariable Long personalidadeId) {
        return service.listarPorPersonalidade(personalidadeId);
    }

    @GetMapping("/escola/{escolaId}")
    public List<VinculoPersonalidadeEscola> listarPorEscola(@PathVariable Long escolaId) {
        return service.listarPorEscola(escolaId);
    }

    @GetMapping("/{id}")
    public ResponseEntity<VinculoPersonalidadeEscola> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> cadastrar(@RequestBody VinculoRequest request) {
        try {
            return ResponseEntity.ok(service.salvar(toEntity(request)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody VinculoRequest request) {
        try {
            return service.atualizar(id, toEntity(request))
                    .map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (service.deletar(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    private VinculoPersonalidadeEscola toEntity(VinculoRequest request) {
        VinculoPersonalidadeEscola vinculo = new VinculoPersonalidadeEscola();

        if (request.vinculoEscolaId() != null && !request.vinculoEscolaId().isBlank()) {
            Escola escola = new Escola();
            escola.setId(Long.parseLong(request.vinculoEscolaId()));
            vinculo.setEscola(escola);
        }

        if (request.vinculoPersonalidadeId() != null && !request.vinculoPersonalidadeId().isBlank()) {
            Personalidade personalidade = new Personalidade();
            personalidade.setId(Long.parseLong(request.vinculoPersonalidadeId()));
            vinculo.setPersonalidade(personalidade);
        }

        if (request.vinculoDataInicio() != null && !request.vinculoDataInicio().isBlank()) {
            vinculo.setDataInicio(LocalDate.parse(request.vinculoDataInicio()));
        }

        if (request.vinculoDataFim() != null && !request.vinculoDataFim().isBlank()) {
            vinculo.setDataFim(LocalDate.parse(request.vinculoDataFim()));
        }

        return vinculo;
    }
}
