package com.carnaval.sistema_carnaval.services;

import com.carnaval.sistema_carnaval.models.Usuario;
import com.carnaval.sistema_carnaval.repositories.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    public Optional<Usuario> buscarPorEmail(String email) {
        return repository.findByEmail(email);
    }

    public Optional<Usuario> buscarPorPreAuthToken(String token) {
        return repository.findByPreAuthToken(token);
    }

    public Usuario salvar(Usuario usuario) {
        return repository.save(usuario);
    }

    // Método administrativo para o "Four-Eyes Principle"
    public boolean desbloquearConta(Long usuarioId) {
        return repository.findById(usuarioId).map(usuario -> {
            usuario.setContaBloqueada(false);
            usuario.setTentativasFalhas(0);
            repository.save(usuario);
            return true;
        }).orElse(false);
    }
}