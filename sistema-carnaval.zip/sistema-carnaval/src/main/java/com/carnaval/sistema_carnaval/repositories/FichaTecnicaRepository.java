package com.carnaval.sistema_carnaval.repositories;

import com.carnaval.sistema_carnaval.models.Cargo;
import com.carnaval.sistema_carnaval.models.FichaTecnica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FichaTecnicaRepository extends JpaRepository<FichaTecnica, Long> {

    List<FichaTecnica> findByDesfileId(Long desfileId);

    @Query("SELECT f FROM FichaTecnica f WHERE " +
           "(:desfileId IS NULL OR f.desfile.id = :desfileId) AND " +
           "(:cargo IS NULL OR f.cargo = :cargo)")
    List<FichaTecnica> buscarComFiltro(
        @Param("desfileId") Long desfileId,
        @Param("cargo") Cargo cargo
    );
}
