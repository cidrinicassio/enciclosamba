package com.carnaval.sistema_carnaval.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "tb_desfiles")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Desfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Integer ano; // Ex: 1993

    private String grupo; // Ex: "Grupo Especial RJ"

    private String enredo;

    private Integer colocacaoFinal; // Ex: 1 (Campeã)

    @ManyToOne // Muitos Desfiles podem pertencer a Uma Escola
    @JoinColumn(name = "escola_id", nullable = false)
    private Escola escola;

    @JsonIgnoreProperties("desfiles")
    @ManyToOne
    @JoinColumn(name = "samba_id", nullable = false)
    private SambaEnredo sambaEnredo;

    @OneToMany(mappedBy = "desfile", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FichaTecnica> fichaTecnica;

}
