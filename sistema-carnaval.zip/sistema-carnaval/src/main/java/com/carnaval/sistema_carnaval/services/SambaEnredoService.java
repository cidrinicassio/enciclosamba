package com.carnaval.sistema_carnaval.services;

import com.carnaval.sistema_carnaval.models.SambaEnredo;
import com.carnaval.sistema_carnaval.repositories.SambaEnredoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class SambaEnredoService {

    private static final Logger log = LoggerFactory.getLogger(SambaEnredoService.class);

    private final SambaEnredoRepository repository;

    public SambaEnredoService(SambaEnredoRepository repository) {
        this.repository = repository;
    }

    public List<SambaEnredo> listarTodos() {
        List<SambaEnredo> resultado = repository.findAll();
        log.debug("Listando todos os sambas-enredo — {} encontrados", resultado.size());
        return resultado;
    }

    public List<SambaEnredo> buscarComFiltro(String titulo, Integer ano) {
        String tituloFiltrado = (titulo != null && !titulo.trim().isEmpty()) ? titulo.trim() : null;
        log.debug("Buscando sambas-enredo com filtro titulo='{}', ano={}", tituloFiltrado, ano);
        List<SambaEnredo> resultado = repository.buscarComFiltro(tituloFiltrado, ano);
        log.debug("Busca de sambas-enredo retornou {} resultado(s)", resultado.size());
        return resultado;
    }

    public Optional<SambaEnredo> buscarPorId(Long id) {
        log.debug("Buscando samba-enredo id={}", id);
        Optional<SambaEnredo> samba = repository.findById(id);
        if (samba.isEmpty()) {
            log.warn("Samba-enredo id={} não encontrado", id);
        }
        return samba;
    }

    public SambaEnredo salvar(SambaEnredo novoSamba) {
        if (novoSamba.getAnoComposicao() != null && novoSamba.getAnoComposicao() > LocalDate.now().getYear()) {
            log.warn("Tentativa de salvar samba-enredo '{}' com anoComposicao={} maior que o ano atual",
                    novoSamba.getTitulo(), novoSamba.getAnoComposicao());
            throw new IllegalArgumentException("O ano de composição não pode ser maior que o ano atual!");
        }
        SambaEnredo salvo = repository.save(novoSamba);
        log.info("Samba-enredo salvo: id={}, titulo='{}', ano={}", salvo.getId(), salvo.getTitulo(), salvo.getAnoComposicao());
        return salvo;
    }

    public Optional<SambaEnredo> atualizar(Long id, SambaEnredo sambaAtualizado) {
        log.debug("Atualizando samba-enredo id={}", id);
        return repository.findById(id).map(sambaExistente -> {
            sambaAtualizado.setId(id);
            SambaEnredo salvo = repository.save(sambaAtualizado);
            log.info("Samba-enredo id={} atualizado: titulo='{}'", id, salvo.getTitulo());
            return salvo;
        }).or(() -> {
            log.warn("Samba-enredo id={} não encontrado para atualizar", id);
            return Optional.empty();
        });
    }

    public boolean deletar(Long id) {
        if (!repository.existsById(id)) {
            log.warn("Samba-enredo id={} não encontrado para deletar", id);
            return false;
        }
        repository.deleteById(id);
        log.info("Samba-enredo id={} deletado", id);
        return true;
    }
}
