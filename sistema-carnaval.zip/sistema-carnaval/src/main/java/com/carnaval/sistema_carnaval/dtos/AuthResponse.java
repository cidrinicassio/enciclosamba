package com.carnaval.sistema_carnaval.dtos;

public record AuthResponse(String mensagem, String preAuthToken, String jwtToken) {
}