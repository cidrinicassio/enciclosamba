package com.carnaval.sistema_carnaval.repositories;

import com.carnaval.sistema_carnaval.models.SambaEnredo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SambaEnredoRepository extends JpaRepository<SambaEnredo, Long> {

    @Query(nativeQuery = true, value =
        "SELECT * FROM tb_samba_enredos WHERE " +
        "(:titulo IS NULL OR " +
        " translate(unaccent(lower(titulo)), '-', ' ') " +
        " LIKE '%' || translate(unaccent(lower(:titulo)), '-', ' ') || '%') AND " +
        "(:ano IS NULL OR ano_composicao = :ano)")
    List<SambaEnredo> buscarComFiltro(
        @Param("titulo") String titulo,
        @Param("ano") Integer ano
    );
}