package com.carnaval.sistema_carnaval.services;

import com.carnaval.sistema_carnaval.dtos.AuthResponse;
import com.carnaval.sistema_carnaval.dtos.LoginRequest;
import com.carnaval.sistema_carnaval.dtos.MfaRequest;
import com.carnaval.sistema_carnaval.models.Usuario;
import com.carnaval.sistema_carnaval.services.mfa.MfaStrategy;
import com.carnaval.sistema_carnaval.services.security.JwtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    private final UsuarioService usuarioService;
    private final MfaStrategy mfaStrategy;
    private final JwtService jwtService;

    public AuthService(UsuarioService usuarioService, MfaStrategy mfaStrategy, JwtService jwtService) {
        this.usuarioService = usuarioService;
        this.mfaStrategy = mfaStrategy;
        this.jwtService = jwtService;
    }

    // PASSO A: Valida senha e gera o desafio MFA
    public AuthResponse iniciarLogin(LoginRequest request) {
        log.info("Tentativa de login para email='{}'", request.email());

        Usuario usuario = usuarioService.buscarPorEmail(request.email())
                .orElseThrow(() -> {
                    log.warn("Login falhou — email não encontrado: '{}'", request.email());
                    return new IllegalArgumentException("E-mail ou senha inválidos.");
                });

        if (usuario.getContaBloqueada()) {
            log.warn("Login bloqueado — conta bloqueada para email='{}'", request.email());
            throw new SecurityException("Conta bloqueada por excesso de tentativas incorretas.");
        }

        // TODO Futuro: Trocar por passwordEncoder.matches() do Spring Security
        if (!usuario.getSenha().equals(request.senha())) {
            int novasTentativas = usuario.getTentativasFalhas() + 1;
            usuario.setTentativasFalhas(novasTentativas);

            if (novasTentativas >= 3) {
                usuario.setContaBloqueada(true);
                usuarioService.salvar(usuario);
                log.warn("Conta bloqueada após 3 tentativas incorretas para email='{}'", request.email());
                throw new SecurityException("Conta bloqueada! Você errou a senha 3 vezes.");
            }

            usuarioService.salvar(usuario);
            log.warn("Senha incorreta para email='{}' — tentativa {}/3", request.email(), novasTentativas);
            throw new IllegalArgumentException("E-mail ou senha inválidos. Tentativa " + novasTentativas + " de 3.");
        }

        String preAuthToken = UUID.randomUUID().toString();
        String codigoGerado = mfaStrategy.gerarEDispararCodigo(usuario);

        usuario.setPreAuthToken(preAuthToken);
        usuario.setCodigoMfaAtual(codigoGerado);
        usuario.setExpiracaoMfa(LocalDateTime.now().plusMinutes(3));
        usuarioService.salvar(usuario);

        log.info("Pré-autenticação concluída para email='{}', código MFA enviado", request.email());
        return new AuthResponse("Pré-autenticação concluída. Enviamos um código para seu e-mail.", preAuthToken, null);
    }

    // PASSO B: Valida o código de 6 dígitos e entrega o prêmio
    public AuthResponse concluirLogin(MfaRequest request) {
        log.debug("Validando código MFA para preAuthToken='{}'", request.preAuthToken());

        Usuario usuario = usuarioService.buscarPorPreAuthToken(request.preAuthToken())
                .orElseThrow(() -> {
                    log.warn("Sessão MFA inválida ou expirada para preAuthToken='{}'", request.preAuthToken());
                    return new IllegalArgumentException("Sessão de validação inválida ou expirada.");
                });

        if (LocalDateTime.now().isAfter(usuario.getExpiracaoMfa())) {
            log.warn("Código MFA expirado para email='{}'", usuario.getEmail());
            throw new IllegalArgumentException("O código MFA expirou! Faça login novamente.");
        }

        if (!mfaStrategy.validarCodigo(usuario, request.codigo())) {
            log.warn("Código MFA incorreto para email='{}'", usuario.getEmail());
            throw new IllegalArgumentException("Código MFA incorreto.");
        }

        usuario.setTentativasFalhas(0);
        usuario.setPreAuthToken(null);
        usuario.setCodigoMfaAtual(null);
        usuarioService.salvar(usuario);

        String jwt = jwtService.gerarToken(usuario);
        log.info("Login concluído com sucesso para email='{}', role={}", usuario.getEmail(), usuario.getRole());
        return new AuthResponse("Login realizado com sucesso!", null, jwt);
    }
}
