package com.carnaval.sistema_carnaval.services.mfa;

import com.carnaval.sistema_carnaval.models.Usuario;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("default") // Roda localmente na sua máquina quando nenhum profile está ativo
public class DevMfaStrategy implements MfaStrategy {

    @Override
    public String gerarEDispararCodigo(Usuario usuario) {
        System.out.println("=== [DEV MODE] Código MFA gerado para " + usuario.getEmail() + ": 123456 ===");
        return "123456"; // Em dev, o código é sempre 123456
    }

    @Override
    public boolean validarCodigo(Usuario usuario, String codigoDigitado) {
        return "123456".equals(codigoDigitado); // Em dev, aceita direto se digitar 123456
    }
}