package com.carnaval.sistema_carnaval.services.mfa;

import com.carnaval.sistema_carnaval.models.Usuario;

public interface MfaStrategy {
    String gerarEDispararCodigo(Usuario usuario);
    boolean validarCodigo(Usuario usuario, String codigoDigitado);
}