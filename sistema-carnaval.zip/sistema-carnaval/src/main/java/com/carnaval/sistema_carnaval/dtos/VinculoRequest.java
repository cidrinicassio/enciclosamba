package com.carnaval.sistema_carnaval.dtos;

public record VinculoRequest(
    String vinculoEscolaId,
    String vinculoPersonalidadeId,
    String vinculoDataInicio,
    String vinculoDataFim
) {}
