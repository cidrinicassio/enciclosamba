package com.carnaval.sistema_carnaval.repositories;

import com.carnaval.sistema_carnaval.models.VinculoPersonalidadeEscola;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VinculoPersonalidadeEscolaRepository extends JpaRepository<VinculoPersonalidadeEscola, Long> {

    List<VinculoPersonalidadeEscola> findByPersonalidadeId(Long personalidadeId);

    List<VinculoPersonalidadeEscola> findByEscolaId(Long escolaId);
}
