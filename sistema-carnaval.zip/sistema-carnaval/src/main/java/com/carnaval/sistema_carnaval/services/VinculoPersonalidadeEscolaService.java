package com.carnaval.sistema_carnaval.services;

import com.carnaval.sistema_carnaval.models.VinculoPersonalidadeEscola;
import com.carnaval.sistema_carnaval.repositories.EscolaRepository;
import com.carnaval.sistema_carnaval.repositories.PersonalidadeRepository;
import com.carnaval.sistema_carnaval.repositories.VinculoPersonalidadeEscolaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VinculoPersonalidadeEscolaService {

    private static final Logger log = LoggerFactory.getLogger(VinculoPersonalidadeEscolaService.class);

    private final VinculoPersonalidadeEscolaRepository repository;
    private final EscolaRepository escolaRepository;
    private final PersonalidadeRepository personalidadeRepository;

    public VinculoPersonalidadeEscolaService(
            VinculoPersonalidadeEscolaRepository repository,
            EscolaRepository escolaRepository,
            PersonalidadeRepository personalidadeRepository) {
        this.repository = repository;
        this.escolaRepository = escolaRepository;
        this.personalidadeRepository = personalidadeRepository;
    }

    public List<VinculoPersonalidadeEscola> listarTodos() {
        List<VinculoPersonalidadeEscola> resultado = repository.findAll();
        log.debug("Listando todos os vínculos — {} encontrados", resultado.size());
        return resultado;
    }

    public List<VinculoPersonalidadeEscola> listarPorPersonalidade(Long personalidadeId) {
        log.debug("Listando vínculos da personalidade id={}", personalidadeId);
        List<VinculoPersonalidadeEscola> resultado = repository.findByPersonalidadeId(personalidadeId);
        log.debug("Vínculos da personalidade id={}: {} encontrados", personalidadeId, resultado.size());
        return resultado;
    }

    public List<VinculoPersonalidadeEscola> listarPorEscola(Long escolaId) {
        log.debug("Listando vínculos da escola id={}", escolaId);
        List<VinculoPersonalidadeEscola> resultado = repository.findByEscolaId(escolaId);
        log.debug("Vínculos da escola id={}: {} encontrados", escolaId, resultado.size());
        return resultado;
    }

    public Optional<VinculoPersonalidadeEscola> buscarPorId(Long id) {
        log.debug("Buscando vínculo id={}", id);
        Optional<VinculoPersonalidadeEscola> vinculo = repository.findById(id);
        if (vinculo.isEmpty()) {
            log.warn("Vínculo id={} não encontrado", id);
        }
        return vinculo;
    }

    public VinculoPersonalidadeEscola salvar(VinculoPersonalidadeEscola vinculo) {
        if (vinculo.getEscola() == null || vinculo.getEscola().getId() == null) {
            log.warn("Tentativa de salvar vínculo sem escola definida");
            throw new IllegalArgumentException("Escola é obrigatória.");
        }
        if (vinculo.getPersonalidade() == null || vinculo.getPersonalidade().getId() == null) {
            log.warn("Tentativa de salvar vínculo sem personalidade definida");
            throw new IllegalArgumentException("Personalidade é obrigatória.");
        }
        if (vinculo.getDataInicio() != null && vinculo.getDataFim() != null
                && vinculo.getDataFim().isBefore(vinculo.getDataInicio())) {
            log.warn("Tentativa de salvar vínculo com dataFim={} anterior a dataInicio={}",
                    vinculo.getDataFim(), vinculo.getDataInicio());
            throw new IllegalArgumentException("A data de fim não pode ser anterior à data de início.");
        }

        log.debug("Salvando vínculo: personalidade id={}, escola id={}, de {} até {}",
                vinculo.getPersonalidade().getId(),
                vinculo.getEscola().getId(),
                vinculo.getDataInicio(),
                vinculo.getDataFim() != null ? vinculo.getDataFim() : "atual");

        vinculo.setEscola(escolaRepository.getReferenceById(vinculo.getEscola().getId()));
        vinculo.setPersonalidade(personalidadeRepository.getReferenceById(vinculo.getPersonalidade().getId()));

        VinculoPersonalidadeEscola salvo = repository.save(vinculo);
        log.info("Vínculo salvo: id={}, personalidade id={}, escola id={}, de {} até {}",
                salvo.getId(),
                salvo.getPersonalidade().getId(),
                salvo.getEscola().getId(),
                salvo.getDataInicio(),
                salvo.getDataFim() != null ? salvo.getDataFim() : "atual");
        return salvo;
    }

    public Optional<VinculoPersonalidadeEscola> atualizar(Long id, VinculoPersonalidadeEscola vinculoAtualizado) {
        log.debug("Atualizando vínculo id={}", id);
        return repository.findById(id).map(existente -> {
            vinculoAtualizado.setId(id);
            VinculoPersonalidadeEscola salvo = salvar(vinculoAtualizado);
            log.info("Vínculo id={} atualizado", id);
            return salvo;
        }).or(() -> {
            log.warn("Vínculo id={} não encontrado para atualizar", id);
            return Optional.empty();
        });
    }

    public boolean deletar(Long id) {
        if (!repository.existsById(id)) {
            log.warn("Vínculo id={} não encontrado para deletar", id);
            return false;
        }
        repository.deleteById(id);
        log.info("Vínculo id={} deletado", id);
        return true;
    }
}
