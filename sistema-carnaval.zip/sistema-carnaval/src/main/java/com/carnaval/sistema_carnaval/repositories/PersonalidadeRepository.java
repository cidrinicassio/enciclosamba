package com.carnaval.sistema_carnaval.repositories;

import com.carnaval.sistema_carnaval.models.Personalidade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PersonalidadeRepository extends JpaRepository<Personalidade, Long> {

    @Query(nativeQuery = true, value =
        "SELECT * FROM tb_personalidades WHERE " +
        "(:nomeCompleto IS NULL OR " +
        " translate(unaccent(lower(nome_completo)), '-', ' ') " +
        " LIKE '%' || translate(unaccent(lower(:nomeCompleto)), '-', ' ') || '%') AND " +
        "(:nomeArtistico IS NULL OR " +
        " translate(unaccent(lower(nome_artistico)), '-', ' ') " +
        " LIKE '%' || translate(unaccent(lower(:nomeArtistico)), '-', ' ') || '%')")
    List<Personalidade> buscarPorNome(
        @Param("nomeCompleto") String nomeCompleto,
        @Param("nomeArtistico") String nomeArtistico
    );
}