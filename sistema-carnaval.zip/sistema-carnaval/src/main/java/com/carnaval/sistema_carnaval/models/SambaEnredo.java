package com.carnaval.sistema_carnaval.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "tb_samba_enredos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SambaEnredo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titulo;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String letra;

    private Integer anoComposicao;

    private String youtubeVideoId;

    private String spotifyTrackId;

    @ManyToMany
    @JoinTable(
        name = "tb_samba_compositores",
        joinColumns = @JoinColumn(name = "samba_id"),
        inverseJoinColumns = @JoinColumn(name = "personalidade_id")
    )
    private List<Personalidade> compositores;

    @JsonIgnoreProperties("sambaEnredo")
    @OneToMany(mappedBy = "sambaEnredo", fetch = FetchType.LAZY)
    private List<Desfile> desfiles;

}