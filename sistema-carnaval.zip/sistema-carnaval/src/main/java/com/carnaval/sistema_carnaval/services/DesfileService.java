package com.carnaval.sistema_carnaval.services;

import com.carnaval.sistema_carnaval.models.Desfile;
import com.carnaval.sistema_carnaval.repositories.DesfileRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class DesfileService {

    private static final Logger log = LoggerFactory.getLogger(DesfileService.class);

    private final DesfileRepository repository;

    public DesfileService(DesfileRepository repository) {
        this.repository = repository;
    }

    public List<Desfile> buscarComFiltro(Integer ano, String nomeEscola) {
        String nomeFiltrado = (nomeEscola != null && !nomeEscola.trim().isEmpty()) ? nomeEscola.trim() : null;
        log.debug("Buscando desfiles com filtro ano={}, nomeEscola='{}'", ano, nomeFiltrado);
        List<Desfile> resultado = repository.buscarPorAnoENomeEscola(ano, nomeFiltrado);
        log.debug("Busca de desfiles retornou {} resultado(s)", resultado.size());
        return resultado;
    }

    public List<Desfile> listarTodos() {
        List<Desfile> resultado = repository.findAll();
        log.debug("Listando todos os desfiles — {} encontrados", resultado.size());
        return resultado;
    }

    public Optional<Desfile> buscarPorId(Long id) {
        log.debug("Buscando desfile id={}", id);
        Optional<Desfile> desfile = repository.findById(id);
        if (desfile.isEmpty()) {
            log.warn("Desfile id={} não encontrado", id);
        }
        return desfile;
    }

    public Desfile salvar(Desfile novoDesfile) {
        if (novoDesfile.getAno() != null && novoDesfile.getAno() > LocalDate.now().getYear()) {
            log.warn("Tentativa de salvar desfile com ano={} maior que o ano atual", novoDesfile.getAno());
            throw new IllegalArgumentException("O ano do desfile não pode ser maior que o ano atual!");
        }
        Desfile salvo = repository.save(novoDesfile);
        log.info("Desfile salvo: id={}, ano={}, escola='{}'",
                salvo.getId(), salvo.getAno(),
                salvo.getEscola() != null ? salvo.getEscola().getNome() : "N/A");
        return salvo;
    }

    public Optional<Desfile> atualizar(Long id, Desfile desfileAtualizado) {
        log.debug("Atualizando desfile id={}", id);
        return repository.findById(id).map(desfileExistente -> {
            desfileAtualizado.setId(id);
            Desfile salvo = repository.save(desfileAtualizado);
            log.info("Desfile id={} atualizado: ano={}", id, salvo.getAno());
            return salvo;
        }).or(() -> {
            log.warn("Desfile id={} não encontrado para atualizar", id);
            return Optional.empty();
        });
    }

    public boolean deletar(Long id) {
        if (!repository.existsById(id)) {
            log.warn("Desfile id={} não encontrado para deletar", id);
            return false;
        }
        repository.deleteById(id);
        log.info("Desfile id={} deletado", id);
        return true;
    }
}
