package com.carnaval.sistema_carnaval.controllers;

import com.carnaval.sistema_carnaval.models.Desfile;
import com.carnaval.sistema_carnaval.services.DesfileService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/desfiles")
public class DesfileController {

    private final DesfileService service;

    public DesfileController(DesfileService service) {
        this.service = service;
    }

    @GetMapping
    public List<Desfile> listarTodos() {
        return service.listarTodos();
    }

    @GetMapping("/filtro")
    public List<Desfile> buscarComFiltro(
            @RequestParam(required = false) Integer ano,
            @RequestParam(required = false) String nomeEscola) {
        return service.buscarComFiltro(ano, nomeEscola);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Desfile> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> cadastrar(@RequestBody Desfile novoDesfile) {
        try {
            return ResponseEntity.ok(service.salvar(novoDesfile));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id:[0-9]+}")
    public ResponseEntity<Desfile> atualizar(@PathVariable Long id, @RequestBody Desfile desfileAtualizado) {
        return service.atualizar(id, desfileAtualizado)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (service.deletar(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}

