package com.carnaval.sistema_carnaval.controllers;

import com.carnaval.sistema_carnaval.models.FichaTecnica;
import com.carnaval.sistema_carnaval.services.FichaTecnicaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/fichas-tecnicas")
public class FichaTecnicaController {

    private final FichaTecnicaService service;

    public FichaTecnicaController(FichaTecnicaService service) {
        this.service = service;
    }

    @GetMapping
    public List<FichaTecnica> listarTodas() {
        return service.listarTodas();
    }

    @GetMapping("/desfile/{desfileId}")
    public List<FichaTecnica> listarPorDesfile(@PathVariable Long desfileId) {
        return service.listarPorDesfile(desfileId);
    }

    @GetMapping("/filtro")
    public ResponseEntity<?> buscarComFiltro(
            @RequestParam(required = false) Long desfileId,
            @RequestParam(required = false) String cargo) {
        try {
            return ResponseEntity.ok(service.buscarComFiltro(desfileId, cargo));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Cargo inválido. Valores aceitos: " + java.util.Arrays.toString(com.carnaval.sistema_carnaval.models.Cargo.values()));
        }
    }

    @GetMapping("/{id:[0-9]+}")
    public ResponseEntity<FichaTecnica> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> cadastrar(@RequestBody FichaTecnica novaFicha) {
        try {
            return ResponseEntity.ok(service.salvar(novaFicha));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id:[0-9]+}")
    public ResponseEntity<FichaTecnica> atualizar(@PathVariable Long id, @RequestBody FichaTecnica fichaAtualizada) {
        return service.atualizar(id, fichaAtualizada)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id:[0-9]+}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (service.deletar(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
