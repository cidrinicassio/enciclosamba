package com.carnaval.sistema_carnaval.services;

import com.carnaval.sistema_carnaval.models.Escola;
import com.carnaval.sistema_carnaval.repositories.EscolaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class EscolaService {

    private static final Logger log = LoggerFactory.getLogger(EscolaService.class);

    private final EscolaRepository repository;

    public EscolaService(EscolaRepository repository) {
        this.repository = repository;
    }

    public List<Escola> listarTodas() {
        List<Escola> resultado = repository.findAll();
        log.debug("Listando todas as escolas — {} encontradas", resultado.size());
        return resultado;
    }

    public List<Escola> buscarComFiltro(String nome) {
        String nomeFiltrado = (nome != null && !nome.trim().isEmpty()) ? nome.trim() : null;
        log.debug("Buscando escolas com filtro nome='{}'", nomeFiltrado);
        List<Escola> resultado = repository.buscarPorNome(nomeFiltrado);
        log.debug("Busca de escolas retornou {} resultado(s)", resultado.size());
        return resultado;
    }

    public Optional<Escola> buscarPorId(Long id) {
        log.debug("Buscando escola id={}", id);
        Optional<Escola> escola = repository.findById(id);
        if (escola.isEmpty()) {
            log.warn("Escola id={} não encontrada", id);
        }
        return escola;
    }

    public Escola salvar(Escola novaEscola) {
        if (novaEscola.getAnoFundacao() != null && novaEscola.getAnoFundacao() > LocalDate.now().getYear()) {
            log.warn("Tentativa de salvar escola com anoFundacao={} maior que o ano atual", novaEscola.getAnoFundacao());
            throw new IllegalArgumentException("O ano de fundação não pode ser maior que o ano atual!");
        }
        Escola salva = repository.save(novaEscola);
        log.info("Escola salva: id={}, nome='{}'", salva.getId(), salva.getNome());
        return salva;
    }

    public Optional<Escola> atualizar(Long id, Escola escolaAtualizada) {
        log.debug("Atualizando escola id={}", id);
        return repository.findById(id).map(escolaExistente -> {
            escolaAtualizada.setId(id);
            Escola salva = repository.save(escolaAtualizada);
            log.info("Escola id={} atualizada: nome='{}'", id, salva.getNome());
            return salva;
        }).or(() -> {
            log.warn("Escola id={} não encontrada para atualizar", id);
            return Optional.empty();
        });
    }

    public boolean deletar(Long id) {
        if (!repository.existsById(id)) {
            log.warn("Escola id={} não encontrada para deletar", id);
            return false;
        }
        repository.deleteById(id);
        log.info("Escola id={} deletada", id);
        return true;
    }
}
