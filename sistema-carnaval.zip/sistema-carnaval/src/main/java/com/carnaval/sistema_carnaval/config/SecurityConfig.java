package com.carnaval.sistema_carnaval.config;

import com.carnaval.sistema_carnaval.services.security.JwtFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtFilter jwtFilter;

    public SecurityConfig(JwtFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/auth/**").permitAll()
                .requestMatchers(HttpMethod.GET,
                    "/escolas/**",
                    "/personalidades/**",
                    "/sambas-enredo/**",
                    "/desfiles/**",
                    "/fichas-tecnicas/**",
                    "/vinculos/**"
                ).permitAll()
                .requestMatchers(HttpMethod.POST,
                    "/escolas/**",
                    "/personalidades/**",
                    "/sambas-enredo/**",
                    "/desfiles/**",
                    "/fichas-tecnicas/**",
                    "/vinculos/**"
                ).hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT,
                    "/escolas/**",
                    "/personalidades/**",
                    "/sambas-enredo/**",
                    "/desfiles/**",
                    "/fichas-tecnicas/**",
                    "/vinculos/**"
                ).hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE,
                    "/escolas/**",
                    "/personalidades/**",
                    "/sambas-enredo/**",
                    "/desfiles/**",
                    "/fichas-tecnicas/**",
                    "/vinculos/**"
                ).hasRole("ADMIN")
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOriginPatterns(List.of("*"));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
