package com.carnaval.sistema_carnaval.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.List;

@Entity // Diz ao JPA que isso vai virar uma tabela no Postgres
@Table(name = "tb_escolas")
@Data // O Lombok gera automaticamente todos os Getters, Setters e o toString() em background
@NoArgsConstructor // Cria o construtor vazio obrigatório do Java
@AllArgsConstructor // Cria o construtor preenchido
public class Escola {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment do ID (Serial)
    private Long id;

    @Column(nullable = false, length = 100) // Campo obrigatório
    private String nome;

    @Column(length = 150)
    private String enderecoQuadra;

    @ManyToOne // Muitas Escolas podem ter Uma Personalidade como presidente
    @JoinColumn(name = "presidente_atual_id")
    private Personalidade presidenteAtual;

    private Integer anoFundacao;
    
    @Column(columnDefinition = "TEXT")
    private String historia;

    private String corPrimaria;
    private String corSecundaria;
    private String corTerciaria;

    @JsonIgnoreProperties("escola")
    @OneToMany(mappedBy = "escola", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<VinculoPersonalidadeEscola> historicoPorPersonalidade;
}