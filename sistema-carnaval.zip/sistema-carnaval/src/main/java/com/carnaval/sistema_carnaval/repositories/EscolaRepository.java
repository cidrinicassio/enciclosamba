package com.carnaval.sistema_carnaval.repositories;

import com.carnaval.sistema_carnaval.models.Escola;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface EscolaRepository extends JpaRepository<Escola, Long> {

    @Query(nativeQuery = true, value =
        "SELECT * FROM tb_escolas WHERE " +
        "(:nome IS NULL OR " +
        " translate(unaccent(lower(nome)), '-', ' ') " +
        " LIKE '%' || translate(unaccent(lower(:nome)), '-', ' ') || '%')")
    List<Escola> buscarPorNome(@Param("nome") String nome);
}