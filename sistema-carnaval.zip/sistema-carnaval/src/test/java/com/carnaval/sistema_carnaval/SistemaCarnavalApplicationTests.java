package com.carnaval.sistema_carnaval;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaCarnavalApplicationTests {

	@Test
	void contextLoads() {
	}

}
