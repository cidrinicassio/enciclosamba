#!/bin/bash

echo "🚀 Iniciando os motores do Enciclosamba..."

# 1. Tenta ligar o container do docker-compose se ele existir, ou o container avulso
if [ -f "docker-compose.yml" ]; then
    docker compose up -d
else
    echo "📦 Ligando o container do Postgres..."
    docker start postgres-carnaval 2>/dev/null || docker start $(docker ps -a -q --filter name=postgres)
fi

# 2. Aguarda o Postgres estar pronto para receber conexões
echo "⏳ Aguardando o banco de dados responder..."
sleep 2

# 3. Sobe a nossa API Spring Boot
echo "🎸 Bateria nota 10! Subindo o Spring Boot..."
./mvnw spring-boot:run